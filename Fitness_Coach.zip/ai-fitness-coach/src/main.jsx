import React from 'react'
// eslint-disable-next-line no-console
console.log('[AFC] app v2.2 — chat-history fix active ✔')
import ReactDOM from 'react-dom/client'
import App from './App.jsx'
import './index.css'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
)
