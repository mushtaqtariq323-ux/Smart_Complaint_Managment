# AI Fitness Coach — User Panel

A premium, fully responsive AI fitness platform built with **React + Vite + Tailwind CSS + Firebase (Auth & Firestore)**.
This build is **100% user panel** — there are no admin routes, components or database logic anywhere in the codebase.

> ⚠️ All BMI / calorie / macro figures are **estimates for general wellness purposes only** — not medical diagnoses.

---

## ✨ Features

| Area | What's included |
|---|---|
| **Authentication** | Firebase email/password signup, login, logout, forgot-password reset email, "Remember me" (local vs session persistence), persistent auth state via `onAuthStateChanged` |
| **Protected routing** | `ProtectedRoute` / `PublicOnly` gates with a branded full-screen loader — protected content is never flashed |
| **Onboarding** | 6-step wizard (personal info → goal → activity → training style → food & allergies → review) that auto-generates and saves your first workout + diet plans |
| **Dashboard** | Current/goal weight, BMI, daily calories, streak, weekly progress ring, today's workout (start / mark completed), today's nutrition with quick logging, weight trend & calorie charts |
| **Body Analysis** | BMI ring + category scale, healthy weight range, BMR/TDEE and goal-based calorie target (labelled estimates) |
| **Workout Plan** | AI-generated weekly split per goal/level/place/duration; sets, reps, rest, difficulty, instructions; guided session runner with timer & rest countdown; replace any exercise; mark completed |
| **Diet Plan** | Calorie & macro targets, breakfast/lunch/dinner/snacks with per-item portions and macros, respects vegetarian preference & free-text allergies |
| **Progress** | Quick entry (weight, calories, protein, workout done, measurements), weight line chart, workout-consistency bars, nutrition vs target, weekly/monthly/all-time views, full history table |
| **AI Coach** | Chat grounded in the user's profile/plans/progress. Understands **English, Urdu (script + Roman) and Roman Sindhi** and replies in the same language. Runs 100% client-side — **no AI provider key in the frontend** |
| **Profile** | View/edit all fitness fields + allergies with live Firestore save |
| **Settings** | Notification preferences (persisted), dark/light mode, Firebase password change (re-auth flow), logout |
| **UX** | Dark/light mode, premium cards, gradients, progress rings, hand-rolled SVG charts, skeletons, empty/error states, toast notifications, mobile-first responsive layout |

## 🔐 Firebase configuration

Config values live in `.env` (see `.env.example`) and are read in `src/services/firebase.js`
with safe fallbacks. Firebase web API keys are public client identifiers — security is enforced
by Firestore rules, not by hiding the key.

## 🛡️ Firestore Security Rules

Deploy `firestore.rules` (root of this repo) from the Firebase console or CLI:

```bash
firebase deploy --only firestore:rules
```

Rules summary — every collection is keyed by the user's UID and locked to it:

```
users/{uid}, fitnessProfiles/{uid}, workouts/{uid} (+ /logs/*),
dietPlans/{uid}, progress/{uid} (+ /entries/*), chatHistory/{uid} (+ /messages/*)
→ allow read, write: if request.auth.uid == uid
```

No `allow read, write: if true` anywhere. All other documents are denied.

## 🚀 Run locally

```bash
npm install
npm run dev      # start dev server
npm run build    # production build
```

## 🧭 User journey

Landing → Signup → Firebase Auth → Login → Fitness Onboarding (auto-generates plans)
→ Dashboard → Body Analysis → Workout → Diet → Progress → AI Coach → Profile → Settings → Logout

## 📁 Structure

```
src/
├── components/       # reusable UI, charts, workout runner
├── context/          # Auth, Data (live Firestore), Theme, Toast
├── hooks/            # (contexts expose shared hooks: useAuth, useData…)
├── layouts/          # DashboardLayout (sidebar/topbar), AuthLayout
├── pages/            # Landing, auth pages, onboarding + 8 app pages
├── routes/           # ProtectedRoute / PublicOnly guards
├── services/
│   ├── firebase.js   # Firebase init (env vars)
│   ├── auth.js       # Firebase Auth wrappers
│   ├── firestore.js  # Firestore CRUD/subscriptions
│   └── ai/           # workout & diet generators + multilingual coach engine (no API keys)
├── utils/            # fitness math, dates, validation, error mapping
└── data/             # exercise & food libraries
```

## 🗄️ Firestore data model

```
users/{uid}                     name, email, onboardingCompleted, settings, createdAt, updatedAt
fitnessProfiles/{uid}           age, gender, height, weight, goal, goalWeight, activityLevel,
                                workoutPreference, experienceLevel, foodPreferences, allergies
workouts/{uid}                  weekly plan (days → exercises) + /logs/{date} completion history
dietPlans/{uid}                 targets, meals (breakfast/lunch/dinner/snacks), totals
progress/{uid}/entries/{date}   weight, calories, protein, workoutCompleted, measurements
chatHistory/{uid}/messages      { role: user|coach, text, lang, createdAt }
```
