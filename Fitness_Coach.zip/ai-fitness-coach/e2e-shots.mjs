import { chromium } from 'playwright'

const BASE = 'http://localhost:5173'
const OUT = '/home/user/screenshots'
const EMAIL = 'demo.athlete.afc@gmail.com'
const PASS = 'FitDemo2026!'
const errors = []

const browser = await chromium.launch()
const page = await browser.newPage({ viewport: { width: 1440, height: 900 } })
page.on('pageerror', (e) => errors.push('PAGEERROR: ' + e.message.slice(0, 160)))
page.on('console', (m) => { if (m.type() === 'error' && !/ERR_CONNECTION_REFUSED|WebSocket/.test(m.text())) errors.push('CONSOLE: ' + m.text().slice(0, 160)) })
page.setDefaultTimeout(25000)
const shot = (name, opts) => page.screenshot({ path: `${OUT}/${name}.png`, ...opts })

async function pageTour() {
  await page.goto(BASE + '/body-analysis', { waitUntil: 'domcontentloaded' })
  await page.getByText('Body Overview').first().waitFor()
  await page.getByLabel('Toggle theme').click()
  await page.waitForTimeout(600)
  await shot('08-body-analysis-light', { fullPage: true })
  await page.getByLabel('Toggle theme').click()

  await page.goto(BASE + '/workout', { waitUntil: 'domcontentloaded' })
  await page.getByText(/exercises · ~/i).first().waitFor()
  await page.waitForTimeout(600)
  await shot('09-workout', { fullPage: true })

  await page.goto(BASE + '/diet', { waitUntil: 'domcontentloaded' })
  await page.getByText('Breakfast').first().waitFor()
  await page.waitForTimeout(600)
  await shot('10-diet', { fullPage: true })

  await page.goto(BASE + '/progress', { waitUntil: 'domcontentloaded' })
  await page.waitForTimeout(1200)
  await shot('11-progress', { fullPage: true })

  await page.goto(BASE + '/ai-coach', { waitUntil: 'domcontentloaded' })
  await page.getByPlaceholder(/Ask your coach/i).fill('aaj kya workout karun?')
  await page.getByLabel('Send message').click()
  await page.waitForTimeout(4000)
  await shot('12-ai-coach-roman-urdu')

  await page.goto(BASE + '/profile', { waitUntil: 'domcontentloaded' })
  await page.getByText('Body Metrics').first().waitFor()
  await shot('13-profile')

  await page.goto(BASE + '/settings', { waitUntil: 'domcontentloaded' })
  await page.getByText('Notification Settings').first().waitFor()
  await shot('14-settings')
}

try {
  // ── 1. Landing ──
  await page.goto(BASE, { waitUntil: 'domcontentloaded' })
  await page.getByText('Your Personal AI-Powered Fitness Companion').first().waitFor()
  await shot('01-landing-hero')
  await page.evaluate(() => document.getElementById('benefits')?.scrollIntoView())
  await page.waitForTimeout(700)
  await shot('02-landing-benefits')

  // ── 2. Signup page ──
  await page.goto(BASE + '/signup', { waitUntil: 'domcontentloaded' })
  await shot('03-signup')

  // ── 3. Signup (idempotent — account may exist from a previous run) ──
  await page.getByLabel('Full Name').fill('Demo Athlete')
  await page.getByLabel('Email').fill(EMAIL)
  await page.getByLabel('Password', { exact: true }).fill(PASS)
  await page.getByLabel('Confirm Password').fill(PASS)
  await page.getByRole('button', { name: /Create Account/i }).click()
  try {
    await page.waitForURL('**/login', { timeout: 20000 })
  } catch {
    await page.goto(BASE + '/login', { waitUntil: 'domcontentloaded' })
  }
  await shot('04-login')

  // ── 4. Login ──
  await page.getByLabel('Email').fill(EMAIL)
  await page.getByRole('textbox', { name: 'Password', exact: true }).fill(PASS)
  await page.getByRole('button', { name: /^Login$/i }).click()
  await page.waitForFunction(() => ['/onboarding', '/dashboard'].includes(location.pathname), null, { timeout: 30000 })

  if (page.url().includes('/onboarding')) {
    // ── 5. Onboarding (first login only) ──
    await page.getByLabel('Age').fill('26')
    await page.getByLabel('Height (cm)').fill('175')
    await page.getByLabel('Weight (kg)').fill('72')
    await shot('05-onboarding-step1')
    await page.getByRole('button', { name: /Continue/i }).click()
    await page.getByRole('button', { name: /Muscle Gain/i }).click()
    await page.getByRole('button', { name: /Continue/i }).click()
    await page.getByRole('button', { name: /Moderately Active/i }).click()
    await page.getByRole('button', { name: /Continue/i }).click()
    await page.getByRole('button', { name: /^Beginner$/i }).click()
    await page.getByRole('button', { name: /Continue/i }).click()
    await page.getByRole('button', { name: /Vegetarian/i }).click()
    await page.getByPlaceholder(/peanuts/i).fill('peanuts')
    await page.keyboard.press('Enter')
    await page.getByRole('button', { name: /Continue/i }).click()
    await shot('06-onboarding-review')
    await page.getByRole('button', { name: /Generate My Plans/i }).click()
    await page.waitForURL('**/dashboard', { timeout: 30000 })
  }

  // ── 6. Dashboard ──
  await page.getByText(/Welcome back/i).first().waitFor()
  await page.waitForTimeout(2500)
  await shot('07-dashboard', { fullPage: true })

  // ── 7-12. All app pages ──
  await pageTour()

  console.log('ALL SCREENSHOTS DONE')
} catch (e) {
  await shot('99-error-state').catch(() => {})
  console.log('FLOW STOPPED:', e.message.slice(0, 240))
} finally {
  console.log(errors.length ? 'RUNTIME ERRORS:\n' + [...new Set(errors)].slice(0, 10).join('\n') : 'NO RUNTIME/CONSOLE ERRORS ✔')
  await browser.close()
}
