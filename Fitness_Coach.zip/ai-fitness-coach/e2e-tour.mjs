import { chromium } from 'playwright'
const BASE = 'http://localhost:5173'
const OUT = '/home/user/screenshots'
const EMAIL = 'demo.athlete.afc@gmail.com'
const PASS = 'FitDemo2026!'
const errors = []

const browser = await chromium.launch()
const ctx = await browser.newContext({ viewport: { width: 1440, height: 900 } })
const page = await ctx.newPage()
page.on('pageerror', (e) => errors.push('PAGEERROR: ' + e.message.slice(0, 140)))
page.on('console', (m) => { if (m.type() === 'error' && !/ERR_CONNECTION_REFUSED|WebSocket|Failed to load resource/.test(m.text())) errors.push('CONSOLE: ' + m.text().slice(0, 140)) })
page.setDefaultTimeout(20000)
const shot = (n, o) => page.screenshot({ path: `${OUT}/${n}.png`, ...o })

try {
  // ── Landing ──
  await page.goto(BASE, { waitUntil: 'domcontentloaded' })
  await page.getByText('Your Personal AI-Powered Fitness Companion').first().waitFor()
  await shot('01-landing-hero')
  await page.evaluate(() => document.getElementById('benefits')?.scrollIntoView())
  await page.waitForTimeout(600)
  await shot('02-landing-benefits')
  await page.evaluate(() => document.getElementById('coach')?.scrollIntoView())
  await page.waitForTimeout(600)
  await shot('02b-landing-coach')

  // ── Auth pages ──
  await page.goto(BASE + '/signup', { waitUntil: 'domcontentloaded' })
  await page.getByText('Create your account').first().waitFor()
  await shot('03-signup')

  await page.goto(BASE + '/login', { waitUntil: 'domcontentloaded' })
  await page.getByText('Welcome back').first().waitFor()
  await shot('04-login')

  // ── Login ──
  await page.getByLabel('Email').fill(EMAIL)
  await page.getByRole('textbox', { name: 'Password', exact: true }).fill(PASS)
  await page.getByRole('button', { name: /^Login$/i }).click()
  await page.waitForFunction(() => ['/onboarding', '/dashboard'].includes(location.pathname), null, { timeout: 30000 })

  // ── Onboarding (reachable regardless of profile state) ──
  await page.goto(BASE + '/onboarding', { waitUntil: 'domcontentloaded' })
  await page.getByText('Personal Information').first().waitFor({ timeout: 15000 }).catch(() => {})
  await page.getByLabel('Age').fill('26').catch(() => {})
  await shot('05-onboarding')

  // ── Dashboard ──
  await page.goto(BASE + '/dashboard', { waitUntil: 'domcontentloaded' })
  await page.getByText(/Welcome back/i).first().waitFor()
  await page.waitForTimeout(2200)
  await shot('07-dashboard', { fullPage: true })

  // ── Body Analysis (light mode) ──
  await page.goto(BASE + '/body-analysis', { waitUntil: 'domcontentloaded' })
  await page.getByText(/Body Overview|Complete your fitness profile/i).first().waitFor()
  await page.getByLabel('Toggle theme').click()
  await page.waitForTimeout(500)
  await shot('08-body-analysis-light', { fullPage: true })
  await page.getByLabel('Toggle theme').click()

  // ── Workout ──
  await page.goto(BASE + '/workout', { waitUntil: 'domcontentloaded' })
  await page.getByText(/Workout Plan|No workout plan yet/i).first().waitFor()
  await page.waitForTimeout(500)
  await shot('09-workout', { fullPage: true })

  // ── Diet ──
  await page.goto(BASE + '/diet', { waitUntil: 'domcontentloaded' })
  await page.getByText(/No diet plan yet|Breakfast/i).first().waitFor()
  await page.waitForTimeout(500)
  await shot('10-diet', { fullPage: true })

  // ── Progress ──
  await page.goto(BASE + '/progress', { waitUntil: 'domcontentloaded' })
  await page.getByText(/No progress data yet|Latest Weight/i).first().waitFor()
  await page.waitForTimeout(900)
  await shot('11-progress', { fullPage: true })

  // ── AI Coach (Roman Urdu) ──
  await page.goto(BASE + '/ai-coach', { waitUntil: 'domcontentloaded' })
  await page.getByLabel('Message your Fitness coach').waitFor()
  await shot('12a-coach-empty-state')
  // real chat send (Groq key absent → honest setup hint, never a fake reply)
  await page.getByLabel('Message your Fitness coach').fill('aaj kya workout karun?')
  await page.keyboard.press('Enter')
  await page.locator('div.group', { hasText: 'aaj kya workout karun?' }).first().waitFor()
  await page.waitForTimeout(3500)
  await shot('12-ai-coach')
  // Shift+Enter keeps a newline without sending
  const coachTa = page.getByLabel('Message your Fitness coach')
  await coachTa.fill('line1')
  await coachTa.press('Shift+Enter')
  await coachTa.type('line2')
  if (!(await coachTa.inputValue()).includes('\n')) throw new Error('Shift+Enter newline lost')
  // New Chat clears the view
  await page.getByRole('button', { name: /New Chat/ }).click()
  await page.getByText('Salam,').first().waitFor()
  await shot('12c-coach-newchat')

  // ── Profile ──
  await page.goto(BASE + '/profile', { waitUntil: 'domcontentloaded' })
  await page.getByText('Account').first().waitFor()
  await page.waitForTimeout(500)
  await shot('13-profile', { fullPage: true })

  // ── Settings ──
  await page.goto(BASE + '/settings', { waitUntil: 'domcontentloaded' })
  await page.getByText('Notification Settings').first().waitFor()
  await shot('14-settings', { fullPage: true })

  // ── Mobile views ──
  const mob = await ctx.newPage()
  await mob.setViewportSize({ width: 390, height: 844 })
  await mob.goto(BASE, { waitUntil: 'domcontentloaded' })
  await mob.waitForTimeout(900)
  await mob.screenshot({ path: `${OUT}/15-mobile-landing.png` })
  await mob.goto(BASE + '/dashboard', { waitUntil: 'domcontentloaded' })
  await mob.getByText(/Welcome back/i).first().waitFor()
  await mob.waitForTimeout(1500)
  await mob.screenshot({ path: `${OUT}/16-mobile-dashboard.png` })
  await mob.getByLabel('Open menu').click()
  await mob.waitForTimeout(600)
  await mob.screenshot({ path: `${OUT}/17-mobile-drawer.png` })
  await mob.close()

  // ── Logout flow ──
  await page.goto(BASE + '/dashboard', { waitUntil: 'domcontentloaded' })
  await page.getByText(/Welcome back/i).first().waitFor()
  await page.getByLabel('Logout').first().click()
  await page.waitForFunction(() => location.pathname === '/', null, { timeout: 15000 })
  await shot('18-logged-out-landing')

  console.log('TOUR COMPLETE')
} catch (e) {
  await shot('99-error-state').catch(() => {})
  console.log('FLOW STOPPED:', e.message.slice(0, 220))
} finally {
  console.log(errors.length ? 'RUNTIME ERRORS:\n' + [...new Set(errors)].slice(0, 8).join('\n') : 'NO RUNTIME/CONSOLE ERRORS ✔')
  await browser.close()
}
