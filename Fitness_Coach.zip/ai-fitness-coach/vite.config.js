import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import { fileURLToPath, URL } from 'node:url'

export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: { '@': fileURLToPath(new URL('./src', import.meta.url)) },
  },
  server: {
    host: '0.0.0.0',
    port: 5173,
    allowedHosts: true,
    hmr: { protocol: 'wss', clientPort: 443 },
    proxy: {
      '/api': { target: `http://localhost:${process.env.PORT || 8787}`, changeOrigin: true },
    },
  },
  preview: { host: '0.0.0.0', allowedHosts: true },
})
